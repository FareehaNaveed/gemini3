import { jsPDF } from 'jspdf';
import * as pdfjsLib from 'pdfjs-dist';

// Initialize PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://esm.sh/pdfjs-dist@4.0.379/build/pdf.worker.mjs`;

export const exportToPDF = (title: string, content: string, id: string) => {
  const doc = new jsPDF();
  
  // Header
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, 210, 40, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.text('CIPHERSYNC SECURITY REPORT', 20, 25);
  
  doc.setFontSize(10);
  doc.text(`SESSION ID: ${id}`, 20, 34);
  doc.text(`DATE: ${new Date().toLocaleString()}`, 140, 34);

  // Body
  doc.setTextColor(30, 41, 59); // slate-800
  doc.setFontSize(14);
  doc.text(title.toUpperCase(), 20, 55);
  
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105); // slate-600
  
  // Split text to fit width
  const splitText = doc.splitTextToSize(content.replace(/[#*]/g, ''), 170);
  doc.text(splitText, 20, 65);
  
  // Footer
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text('CONFIDENTIAL - CIPHERSYNC SECURITY', 75, 285);
  }

  doc.save(`CipherSync_${id}.pdf`);
};

export const exportAllToPDF = (history: any[]) => {
  const doc = new jsPDF();
  let yOffset = 20;

  // Cover Page
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 210, 297, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(30);
  doc.text('CIPHERSYNC', 20, 100);
  doc.setFontSize(20);
  doc.text('CONSOLIDATED AUDIT VAULT', 20, 120);
  doc.setFontSize(10);
  doc.text(`Total Records: ${history.length}`, 20, 140);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 150);

  history.forEach((audit, index) => {
    doc.addPage();
    yOffset = 20;

    // Header per page
    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, 210, 30, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(12);
    doc.text(`RECORD ${index + 1}: ${audit.id}`, 20, 18);
    doc.setFontSize(8);
    doc.text(`${audit.type} | ${audit.timestamp}`, 20, 24);

    doc.setTextColor(30, 41, 59);
    doc.setFontSize(12);
    doc.text(audit.summary.toUpperCase(), 20, 45);

    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    const splitContent = doc.splitTextToSize(audit.content.substring(0, 3000), 170);
    doc.text(splitContent, 20, 55);
  });

  doc.save(`CipherSync_Full_Vault_${new Date().getTime()}.pdf`);
};

export const extractTextFromPDF = async (file: File): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let fullText = '';
  
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageText = textContent.items.map((item: any) => item.str).join(' ');
    fullText += pageText + '\n';
  }
  
  return fullText;
};