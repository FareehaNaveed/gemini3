import React, { useState } from 'react';
import { runCodeAudit, runCloudGuard } from '../geminiService';
import { exportToPDF, extractTextFromPDF } from '../utils/pdfUtils';
import { 
  ShieldCheck, 
  Loader2, 
  FileCode, 
  Brackets, 
  Download, 
  FileUp, 
  ImageIcon, 
  Zap, 
  Cloud,
  Layers,
  Activity,
  Search,
  Check,
  X,
  ShieldAlert,
  AlertCircle,
  Info
} from 'lucide-react';

interface SecurityAuditorProps {
  onAuditComplete: (res: { type: 'CODE' | 'CLOUD'; content: string; summary: string; remediation?: string; score?: number }) => void;
}

const SecurityAuditor: React.FC<SecurityAuditorProps> = ({ onAuditComplete }) => {
  const [activeSubTab, setActiveSubTab] = useState<'CODE' | 'CLOUD'>('CODE');
  const [input, setInput] = useState('');
  const [auditResult, setAuditResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [showFixPreview, setShowFixPreview] = useState(false);
  const [pendingFix, setPendingFix] = useState<string | null>(null);

  const handleAudit = async () => {
    if (!input.trim() && !imageBase64) return;
    setLoading(true);
    setAuditResult(null);
    setShowFixPreview(false);

    try {
      const res = activeSubTab === 'CODE' 
        ? await runCodeAudit(input, imageBase64 || undefined)
        : await runCloudGuard(input, imageBase64 || undefined);
      
      setAuditResult(res);

      onAuditComplete({
        type: activeSubTab,
        content: input,
        summary: res.summary || `Automated ${activeSubTab} Scan`,
        remediation: activeSubTab === 'CODE' ? res.fullRemediatedCode : undefined,
        score: activeSubTab === 'CLOUD' ? res.score : undefined
      });
    } catch (e) {
      alert('FAULT_DETECTED: Analysis process failed.');
    } finally {
      setLoading(false);
    }
  };

  const initiateRemediation = () => {
    if (activeSubTab === 'CODE' && auditResult?.fullRemediatedCode) {
      setPendingFix(auditResult.fullRemediatedCode);
      setShowFixPreview(true);
    } else {
      alert("Manual Remediation required for Cloud Configs based on report findings.");
    }
  };

  const applyPendingFix = () => {
    if (pendingFix) {
      setInput(pendingFix);
      setShowFixPreview(false);
      setPendingFix(null);
      alert("ZERO_EFFORT_REMEDIATION: Primary buffer patched with security logic.");
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.name.endsWith('.pdf')) {
        setLoading(true);
        extractTextFromPDF(file).then(txt => {
          setInput(txt);
          setLoading(false);
        });
      } else {
        const reader = new FileReader();
        reader.onload = (ev) => setInput(ev.target?.result as string);
        reader.readAsText(file);
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = (event.target?.result as string).split(',')[1];
        setImageBase64(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const getSeverityStyles = (severity: string) => {
    switch(severity?.toUpperCase()) {
      case 'CRITICAL': return { bg: 'bg-red-500/10', border: 'border-red-500/20', text: 'text-red-500', icon: <ShieldAlert className="w-4 h-4" /> };
      case 'WARNING': return { bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-500', icon: <AlertCircle className="w-4 h-4" /> };
      default: return { bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', text: 'text-cyan-500', icon: <Info className="w-4 h-4" /> };
    }
  };

  return (
    <div className="space-y-12 font-mono">
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-8">
        <div className="space-y-2">
          <h2 className="text-5xl font-black text-white tracking-tighter uppercase leading-none">SEC AUDITOR</h2>
          <div className="flex items-center gap-4">
            <Zap className="w-5 h-5 text-cyan-400" />
            <p className="text-cyan-500/60 uppercase text-[11px] tracking-[0.4em] font-black">NEURAL DEEP SCAN v4.28</p>
          </div>
        </div>

        <div className="flex bg-slate-900/50 p-2.5 rounded-[2.5rem] border border-slate-800 shadow-2xl backdrop-blur-xl border-t-white/5">
          <button 
            onClick={() => { setActiveSubTab('CODE'); setAuditResult(null); setShowFixPreview(false); }}
            className={`px-10 py-4 rounded-[1.8rem] text-[10px] font-black transition-all tracking-[0.2em] uppercase ${activeSubTab === 'CODE' ? 'bg-cyan-600 text-slate-950 shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
          >
            SAST NODE
          </button>
          <button 
            onClick={() => { setActiveSubTab('CLOUD'); setAuditResult(null); setShowFixPreview(false); }}
            className={`px-10 py-4 rounded-[1.8rem] text-[10px] font-black transition-all tracking-[0.2em] uppercase ${activeSubTab === 'CLOUD' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
          >
            CSPM NODE
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 min-h-[650px]">
        {/* Buffer Area */}
        <div className="flex flex-col space-y-8">
          <div className="flex-1 bg-slate-900/40 border border-slate-800/80 rounded-[3.5rem] overflow-hidden flex flex-col shadow-2xl relative backdrop-blur-xl group border-t-white/5">
            <div className="bg-slate-800/30 px-10 py-5 border-b border-slate-800/50 flex justify-between items-center">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-3">
                <Activity size={16} className="text-cyan-400 animate-pulse" />
                BUFFER STREAM INPUT
              </span>
              <div className="flex gap-6">
                <label className="cursor-pointer text-slate-500 hover:text-cyan-400 transition-all hover:scale-110">
                  <FileUp size={20} />
                  <input type="file" className="hidden" onChange={handleFileUpload} />
                </label>
                <label className="cursor-pointer text-slate-500 hover:text-cyan-400 transition-all hover:scale-110">
                  <ImageIcon size={20} />
                  <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                </label>
              </div>
            </div>
            {loading && <div className="absolute inset-0 z-10 scan-line opacity-30"></div>}
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Awaiting ${activeSubTab === 'CODE' ? 'source code payload' : 'cloud configuration stream'}...`}
              className="flex-1 bg-transparent p-12 text-slate-300 font-mono text-sm resize-none focus:outline-none placeholder:text-slate-700 leading-relaxed scrollbar-hide"
            />
            {imageBase64 && (
              <div className="p-5 px-10 bg-cyan-500/5 border-t border-cyan-500/10 flex justify-between items-center">
                <span className="text-[10px] text-cyan-400 font-black tracking-[0.2em] uppercase">VISION BUFFER LOCKED</span>
                <button onClick={() => setImageBase64(null)} className="text-red-500/50 hover:text-red-500 text-[10px] uppercase font-black tracking-widest transition-colors">WIPE PAYLOAD</button>
              </div>
            )}
          </div>
          <button
            onClick={handleAudit}
            disabled={loading || (!input.trim() && !imageBase64)}
            className="w-full py-7 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-900/60 disabled:text-slate-600 text-slate-950 rounded-[2.5rem] font-black flex items-center justify-center space-x-5 transition-all duration-500 shadow-[0_20px_50px_rgba(8,145,178,0.25)] disabled:shadow-none uppercase tracking-[0.4em] text-xs group hover:scale-[1.02] active:scale-95 border-t-white/10"
          >
            {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : activeSubTab === 'CODE' ? <ShieldCheck className="w-6 h-6" /> : <Cloud className="w-6 h-6" />}
            <span className="tracking-widest">{loading ? "PROCESSING STREAM..." : "EXECUTE SECURITY SCAN"}</span>
          </button>
        </div>

        {/* Intelligence Area */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-[3.5rem] overflow-hidden flex flex-col relative shadow-2xl backdrop-blur-xl border-t-white/5">
          <div className="bg-slate-800/30 px-10 py-5 border-b border-slate-800/50 flex justify-between items-center">
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-3">
              <Layers size={16} className="text-indigo-400" />
              INTELLIGENCE OUTPUT STREAM
            </span>
            <div className="flex space-x-6 items-center">
               {auditResult && (
                 <button onClick={() => exportToPDF(`${activeSubTab} Report`, JSON.stringify(auditResult, null, 2), "CS-LOG-2026")} className="p-2 text-slate-400 hover:text-white transition-all hover:scale-110" title="Export Security PDF">
                   <Download size={22} />
                 </button>
               )}
            </div>
          </div>

          <div className="flex-1 p-10 overflow-auto font-mono text-sm text-slate-400 scrollbar-hide">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-8">
                <div className="relative">
                  <div className="w-24 h-24 border-[10px] border-cyan-500/5 rounded-full"></div>
                  <div className="absolute inset-0 w-24 h-24 border-t-[10px] border-cyan-400 rounded-full animate-spin"></div>
                </div>
                <div className="text-center font-mono uppercase text-[10px] text-cyan-500/40 tracking-[0.6em] font-black animate-pulse">Scanning Memory Space</div>
              </div>
            ) : auditResult ? (
              <div className="space-y-8">
                {/* Remediate Preview window opening above results */}
                {showFixPreview && (
                  <div className="animate-in slide-in-from-top-4 duration-500 p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl mb-8 relative overflow-hidden backdrop-blur-xl">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-3">
                        <Zap size={16} className="text-emerald-400 fill-current" />
                        <span className="text-[11px] font-black text-emerald-400 uppercase tracking-widest">Remediation Blueprint Locked</span>
                      </div>
                      <button onClick={() => setShowFixPreview(false)} className="text-slate-500 hover:text-white transition-colors">
                        <X size={18} />
                      </button>
                    </div>
                    <div className="bg-slate-950/80 p-6 rounded-2xl border border-slate-800 text-xs max-h-48 overflow-auto mb-6 whitespace-pre text-emerald-100/70 scrollbar-hide font-mono leading-relaxed">
                      {pendingFix}
                    </div>
                    <button 
                      onClick={applyPendingFix}
                      className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-[11px] font-black rounded-2xl transition-all uppercase tracking-[0.3em] flex items-center justify-center gap-3 shadow-xl shadow-emerald-500/10"
                    >
                      <Check size={18} /> Sync Remediation to Buffer
                    </button>
                  </div>
                )}

                {activeSubTab === 'CLOUD' && auditResult.score !== undefined && (
                  <div className="flex flex-col items-center p-10 bg-slate-950/60 rounded-[3rem] border border-slate-800/60 shadow-inner">
                    <div className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em] mb-4 opacity-60">Posture Index</div>
                    <div className={`text-7xl font-black tracking-tighter ${auditResult.score > 70 ? 'text-emerald-400' : auditResult.score > 40 ? 'text-amber-400' : 'text-rose-400'}`}>
                      {auditResult.score}<span className="text-2xl opacity-20">/100</span>
                    </div>
                  </div>
                )}

                <div className="p-6 bg-slate-950/60 border border-slate-800 rounded-3xl">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Executive Summary</p>
                  <p className="text-slate-300 leading-relaxed text-xs">{auditResult.summary}</p>
                </div>

                <div className="space-y-6">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2">Findings Catalog</p>
                  {(activeSubTab === 'CODE' ? auditResult.vulnerabilities : auditResult.findings)?.map((item: any, i: number) => {
                    const style = getSeverityStyles(item.severity);
                    return (
                      <div key={i} className={`p-6 rounded-[2rem] border ${style.bg} ${style.border} space-y-4 transition-all hover:bg-white/5`}>
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <div className={`${style.text}`}>{style.icon}</div>
                            <h4 className="font-bold text-white uppercase tracking-tight text-xs">{item.title}</h4>
                          </div>
                          <span className={`text-[8px] font-black px-2 py-0.5 rounded border ${style.border} ${style.text}`}>{item.severity}</span>
                        </div>
                        <p className="text-slate-400 leading-relaxed text-[11px]">{activeSubTab === 'CODE' ? item.impact : item.blastRadius}</p>
                        <div className="space-y-3">
                          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 text-[10px] overflow-x-auto text-slate-500 whitespace-pre scrollbar-hide">
                            {activeSubTab === 'CODE' ? item.fixSnippet : item.remediation}
                          </div>
                          <div className="flex justify-end pt-2">
                            <button 
                              onClick={initiateRemediation}
                              className={`flex items-center gap-2 px-6 py-3 bg-slate-900 border ${style.border} ${style.text} text-[10px] font-black rounded-xl hover:bg-slate-800 transition-all uppercase tracking-widest shadow-lg`}
                            >
                              <Zap size={12} fill="currentColor" /> Remediate
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-[0.03] grayscale select-none pointer-events-none transition-opacity duration-1000">
                <Search size={180} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityAuditor;