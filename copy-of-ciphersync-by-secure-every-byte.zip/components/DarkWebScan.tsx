
import React, { useState } from 'react';
import { checkDataBreach } from '../geminiService';
import { Search, Loader2, EyeOff, ShieldAlert, AlertTriangle, CheckCircle, Database, Lock } from 'lucide-react';

interface DarkWebScanProps {
  onAuditComplete: (res: { content: string; summary: string }) => void;
}

const DarkWebScan: React.FC<DarkWebScanProps> = ({ onAuditComplete }) => {
  const [identifier, setIdentifier] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleScan = async () => {
    if (!identifier.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const res = await checkDataBreach(identifier);
      setResult(res || '');
      onAuditComplete({ content: identifier, summary: `Dark Web Scan: ${identifier}` });
    } catch (e) {
      setResult('Error: ' + (e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <header>
        <h2 className="text-3xl font-extrabold text-white tracking-tight font-mono">Dark Web Monitor</h2>
        <p className="text-slate-400 mt-1 uppercase text-xs tracking-widest font-bold">Data Breach Intelligence Engine</p>
      </header>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[100px] pointer-events-none"></div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white">Identity Surveillance</h3>
          </div>
          <div className="relative group">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-600 group-focus-within:text-indigo-400 transition-colors" />
            <input 
              type="text" 
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder="Enter email or username to check leaks..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-12 pr-4 py-4 text-slate-100 font-mono text-sm focus:outline-none focus:border-indigo-500/50 transition-all"
            />
          </div>
          <button 
            onClick={handleScan}
            disabled={loading || !identifier.trim()}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold flex items-center justify-center space-x-3 transition-all disabled:bg-slate-800 uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(99,102,241,0.2)]"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <EyeOff className="w-5 h-5" />}
            <span>{loading ? "Scanning Leaked Repositories..." : "Scan Dark Web Databases"}</span>
          </button>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-6 min-h-[200px] relative">
          {loading && <div className="absolute inset-0 z-10 scan-line"></div>}
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4 font-mono flex items-center gap-2">
            <ShieldAlert size={12} className="text-indigo-400" />
            Intelligence Report Response
          </div>
          
          <div className="font-mono text-sm leading-relaxed text-slate-300">
            {loading ? (
              <div className="h-32 flex flex-col items-center justify-center space-y-2 opacity-50 italic">
                <span>Connecting to Onion Nodes...</span>
              </div>
            ) : result ? (
              <div className="whitespace-pre-wrap animate-in fade-in duration-700">
                {result.replace(/[#*]/g, '')}
              </div>
            ) : (
              <div className="h-32 flex flex-col items-center justify-center text-slate-700 text-center opacity-30 italic">
                <Search className="w-12 h-12 mb-2" />
                <p>Input target identity for surveillance.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DarkWebScan;
