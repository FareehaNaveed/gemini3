
import React, { useState, useEffect } from 'react';
import { runIntelScan } from '../geminiService';
import { 
  Search, 
  Loader2, 
  EyeOff, 
  ShieldAlert, 
  Database, 
  Lock, 
  Key, 
  Clock, 
  Zap, 
  Globe,
  Fingerprint,
  User,
  LayoutGrid
} from 'lucide-react';

interface IdentityIntelProps {
  onAuditComplete: (res: { type: 'URL' | 'OSINT' | 'BREACH' | 'PASSWORD'; content: string; summary: string }) => void;
}

const IdentityIntel: React.FC<IdentityIntelProps> = ({ onAuditComplete }) => {
  const [activeMode, setActiveMode] = useState<'BREACH' | 'OSINT' | 'PASSWORD'>('BREACH');
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [passStats, setPassStats] = useState({ entropy: 0, crackTime: 'N/A', complexity: 'Low' });

  useEffect(() => {
    if (activeMode === 'PASSWORD') {
      calculatePasswordStats();
    }
  }, [input, activeMode]);

  const calculatePasswordStats = () => {
    if (!input) return;
    let charset = 0;
    if (/[a-z]/.test(input)) charset += 26;
    if (/[A-Z]/.test(input)) charset += 26;
    if (/[0-9]/.test(input)) charset += 10;
    if (/[^a-zA-Z0-9]/.test(input)) charset += 32;

    const entropy = Math.round(input.length * Math.log2(charset));
    const secondsToCrack = Math.pow(charset, input.length) / 10_000_000_000;

    let timeText = 'Centuries';
    if (secondsToCrack < 1) timeText = 'Instant';
    else if (secondsToCrack < 3600) timeText = `${Math.round(secondsToCrack / 60)}m`;
    else if (secondsToCrack < 86400) timeText = `${Math.round(secondsToCrack / 3600)}h`;
    else if (secondsToCrack < 31536000) timeText = `${Math.round(secondsToCrack / 86400)}d`;

    setPassStats({ 
      entropy, 
      crackTime: timeText, 
      complexity: entropy > 90 ? 'Elite' : entropy > 60 ? 'High' : 'Low' 
    });
  };

  const handleScan = async () => {
    if (!input.trim() || activeMode === 'PASSWORD') return;
    setLoading(true);
    setResult('');
    try {
      const res = await runIntelScan(activeMode === 'BREACH' ? 'BREACH' : 'USER', input);
      setResult(res);
      onAuditComplete({ type: activeMode as any, content: input, summary: `${activeMode}_INTELLIGENCE_REPORT` });
    } catch (e) {
      setResult('SCAN_FAULT: ' + (e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 max-w-5xl mx-auto font-['Inter']">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-2">
          <h2 className="text-5xl font-black text-white tracking-tighter font-mono uppercase leading-none">INTEL_SURVEILLANCE</h2>
          <div className="flex items-center gap-4">
            <Fingerprint className="w-5 h-5 text-cyan-400" />
            <p className="text-cyan-500/60 uppercase text-[11px] tracking-[0.4em] font-black font-mono">Module v2.4 :: Deep OSINT Scan</p>
          </div>
        </div>

        <div className="flex bg-slate-900/50 p-2.5 rounded-[2.5rem] border border-slate-800 shadow-2xl backdrop-blur-xl border-t-white/5">
          {[
            { id: 'BREACH', label: 'DARK_WEB', icon: EyeOff },
            { id: 'OSINT', label: 'OSINT_NODE', icon: Globe },
            { id: 'PASSWORD', label: 'CRYPT_CHECK', icon: Key },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => { setActiveMode(tab.id as any); setInput(''); setResult(''); }}
              className={`flex items-center gap-4 px-8 py-4 rounded-[1.8rem] text-[10px] font-black font-mono transition-all tracking-[0.2em] uppercase ${activeMode === tab.id ? 'bg-indigo-600 text-white shadow-lg scale-105' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="bg-slate-900/30 border border-slate-800/80 rounded-[3.5rem] p-12 sm:p-16 space-y-12 shadow-2xl relative overflow-hidden backdrop-blur-xl border-t-white/5">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/5 blur-[130px] pointer-events-none"></div>
        
        <div className="space-y-8">
          <div className="flex items-center space-x-4">
            <Database className="w-6 h-6 text-indigo-400" />
            <h3 className="text-2xl font-black text-white font-mono uppercase tracking-tight leading-none">Identity Input Stream</h3>
          </div>
          <div className="relative group">
            <Lock className="absolute left-8 top-1/2 -translate-y-1/2 w-7 h-7 text-slate-600 group-focus-within:text-indigo-400 transition-all duration-500" />
            <input 
              type={activeMode === 'PASSWORD' ? 'password' : 'text'} 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={activeMode === 'PASSWORD' ? "Enter cryptographic secret..." : "Enter entity identifier (email/handle)..."}
              className="w-full bg-slate-950 border border-slate-800 rounded-[2.5rem] pl-20 pr-10 py-7 text-slate-100 font-mono text-xl focus:outline-none focus:border-indigo-500/50 transition-all shadow-inner font-medium"
            />
          </div>
          {activeMode !== 'PASSWORD' && (
            <button 
              onClick={handleScan}
              disabled={loading || !input.trim()}
              className="w-full py-7 bg-indigo-600 hover:bg-indigo-500 text-slate-950 rounded-[2.5rem] font-black flex items-center justify-center space-x-5 transition-all duration-500 disabled:bg-slate-900/60 uppercase tracking-[0.4em] text-xs font-mono shadow-[0_20px_50px_rgba(99,102,241,0.25)] hover:scale-[1.02] active:scale-95 border-t-white/10"
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Search className="w-6 h-6" />}
              <span>{loading ? "SEARCHING_DATA_SHARDS..." : "EXECUTE_DEEP_SURVEILLANCE"}</span>
            </button>
          )}
        </div>

        {activeMode === 'PASSWORD' && input && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
            {[
              { label: 'CRACK WINDOW', val: passStats.crackTime, icon: Clock, color: 'text-indigo-400' },
              { label: 'BIT ENTROPY', val: passStats.entropy, icon: Zap, color: 'text-yellow-400' },
              { label: 'AUDIT STATUS', val: passStats.complexity, icon: ShieldAlert, color: 'text-green-400' }
            ].map((s, idx) => (
              <div key={idx} className="bg-slate-950/60 p-10 rounded-[3rem] border border-slate-800 text-center flex flex-col items-center shadow-xl hover:border-white/5 transition-all">
                <s.icon className={`w-10 h-10 ${s.color} mb-6`} />
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-2 font-mono opacity-60">{s.label}</div>
                <div className="text-4xl font-black text-white font-mono tracking-tighter uppercase leading-none">{s.val}</div>
              </div>
            ))}
          </div>
        )}

        {activeMode !== 'PASSWORD' && (
          <div className="bg-slate-950/80 border border-slate-800 rounded-[3rem] p-12 min-h-[350px] relative shadow-2xl border-t-white/5">
            {loading && <div className="absolute inset-0 z-10 scan-line opacity-30"></div>}
            <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-10 font-mono flex items-center gap-4 opacity-60">
              <ShieldAlert size={16} className="text-indigo-400" />
              INTELLIGENCE_RECON_REPORT
            </div>
            
            <div className="font-mono text-sm leading-relaxed text-slate-400 font-medium">
              {loading ? (
                <div className="h-48 flex flex-col items-center justify-center space-y-6 opacity-40 italic">
                  <div className="w-12 h-12 border-[6px] border-indigo-400/10 border-t-indigo-400 rounded-full animate-spin"></div>
                  <span className="text-[10px] uppercase font-black tracking-[0.5em] font-mono">Querying Global Onion Nodes</span>
                </div>
              ) : result ? (
                <div className="whitespace-pre-wrap animate-in fade-in duration-1000 tracking-tight leading-relaxed">
                  {result}
                </div>
              ) : (
                <div className="h-48 flex flex-col items-center justify-center text-slate-800 text-center opacity-30 select-none transition-opacity duration-1000">
                  <LayoutGrid size={100} className="mb-6" />
                  <p className="text-[11px] font-black uppercase tracking-[0.5em] font-mono">Awaiting Identity Context</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IdentityIntel;
