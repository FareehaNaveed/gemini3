import React from 'react';
import { Linkedin, Github, ShieldCheck, Cpu } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-auto py-8 px-10 border-t border-slate-900 bg-slate-950/80 backdrop-blur-xl z-30">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        {/* Brand Meta */}
        <div className="flex flex-col items-center md:items-start space-y-2">
          <div className="flex items-center space-x-3 text-slate-300">
            <ShieldCheck size={18} className="text-cyan-400" />
            <span className="text-sm font-black tracking-tighter font-mono uppercase">CIPHERSYNC</span>
          </div>
          <div className="flex items-center space-x-2 text-[10px] font-bold text-slate-600 uppercase tracking-[0.3em]">
             <Cpu size={10} />
             <span>Neural Defense Framework</span>
          </div>
        </div>
        
        {/* Personal Branding */}
        <div className="flex items-center space-x-10">
          <div className="text-center md:text-right">
            <div className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Architecture & Code</div>
            <div className="text-sm font-black text-white hover:text-cyan-400 transition-colors cursor-pointer">Security Engineer • @CIPHERSYNC</div>
          </div>
          
          {/* Social Cluster */}
          <div className="flex space-x-3">
            <a 
              href="https://linkedin.com" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-3 bg-slate-900/50 border border-slate-800 rounded-2xl text-slate-500 hover:text-cyan-400 hover:border-cyan-400/40 transition-all duration-300 shadow-xl btn-interact"
            >
              <Linkedin size={18} />
            </a>
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-3 bg-slate-900/50 border border-slate-800 rounded-2xl text-slate-500 hover:text-white hover:border-slate-700 transition-all duration-300 shadow-xl btn-interact"
            >
              <Github size={18} />
            </a>
          </div>
        </div>
      </div>
      
      {/* Absolute Bottom Tag */}
      <div className="max-w-7xl mx-auto mt-6 text-center">
        <p className="text-[9px] text-slate-700 font-bold uppercase tracking-[0.5em] font-mono">
          Proprietary Intelligence Core • Secure Session
        </p>
      </div>
    </footer>
  );
};

export default Footer;