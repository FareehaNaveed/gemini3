import React, { useState, useRef } from 'react';
import { runCodeAudit } from '../geminiService';
import { exportToPDF, extractTextFromPDF } from '../utils/pdfUtils';
import { ShieldCheck, Loader2, Download, Zap, Search, Terminal, Upload, ShieldAlert, AlertCircle, Info, Check, X } from 'lucide-react';
import MatrixRain from './MatrixRain';

const CodeAuditor: React.FC<{onAuditComplete: any}> = ({ onAuditComplete }) => {
  const [input, setInput] = useState('');
  const [auditResult, setAuditResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [fixing, setFixing] = useState<number | null>(null);
  const [showFixPreview, setShowFixPreview] = useState(false);
  const [pendingFix, setPendingFix] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAudit = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setAuditResult(null);
    setShowFixPreview(false);
    try {
      const res = await runCodeAudit(input);
      setAuditResult(res);
      onAuditComplete({ 
        content: input, 
        summary: res.summary || 'Vulnerability audit session complete', 
        type: 'CODE'
      });
    } catch (e) {
      console.error(e);
      alert("Scan Interrupted: Network or processing fault.");
    } finally {
      setLoading(false);
    }
  };

  const initiateFix = (index: number) => {
    setFixing(index);
    // In a real granular fix, we'd prompt the AI for just this snippet. 
    // Here we use the fullRemediatedCode as the gold standard for 'Zero-Effort'.
    setPendingFix(auditResult.fullRemediatedCode);
    setShowFixPreview(true);
  };

  const applyPendingFix = () => {
    if (pendingFix) {
      setInput(pendingFix);
      setShowFixPreview(false);
      setPendingFix(null);
      setFixing(null);
      // Optional: re-scan or just notify
      alert("Zero-Effort Patch Applied: Security logic synchronized with source buffer.");
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      if (file.type === 'application/pdf') {
        const text = await extractTextFromPDF(file);
        setInput(text);
      } else {
        const reader = new FileReader();
        reader.onload = (event) => setInput(event.target?.result as string);
        reader.readAsText(file);
      }
    } catch (error) {
      alert("Import Failed.");
    } finally {
      setLoading(false);
      if (e.target) e.target.value = '';
    }
  };

  const getSeverityStyles = (severity: string) => {
    switch(severity.toUpperCase()) {
      case 'CRITICAL': return { bg: 'bg-red-500/10', border: 'border-red-500/20', text: 'text-red-500', icon: <ShieldAlert className="w-4 h-4" /> };
      case 'WARNING': return { bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-500', icon: <AlertCircle className="w-4 h-4" /> };
      default: return { bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', text: 'text-cyan-500', icon: <Info className="w-4 h-4" /> };
    }
  };

  return (
    <div className="space-y-8 relative">
      {loading && <MatrixRain />}
      
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 z-10 relative">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase font-mono">Code Auditor</h2>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse"></span>
            <p className="text-cyan-500/60 uppercase text-[9px] tracking-[0.3em] font-black font-mono">Module Status: Operational</p>
          </div>
        </div>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="bg-slate-900/80 px-5 py-3 rounded-xl border border-slate-800 text-[9px] font-black font-mono uppercase tracking-[0.1em] text-slate-400 hover:text-cyan-400 transition-all flex items-center gap-2 backdrop-blur-md"
        >
          <Upload size={14} /> Import Data
          <input ref={fileInputRef} type="file" className="hidden" accept=".txt,.js,.ts,.py,.c,.cpp,.h,.pdf" onChange={handleFileChange} />
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 min-h-[500px] z-10 relative">
        <div className="flex flex-col space-y-4">
          <div className="flex-1 bg-slate-950/60 border border-slate-800/80 rounded-2xl overflow-hidden flex flex-col relative backdrop-blur-md shadow-xl">
            <div className="bg-slate-900/80 px-6 py-3 border-b border-slate-800/50 text-[9px] font-black text-slate-500 font-mono uppercase tracking-widest flex items-center gap-2">
              <Terminal size={12} className="text-cyan-500" />
              Source Stream
            </div>
            <textarea 
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              placeholder="Paste source payload for analysis..." 
              className="flex-1 bg-transparent p-6 text-cyan-50 font-mono text-xs resize-none focus:outline-none placeholder:text-slate-800 leading-relaxed scrollbar-hide" 
            />
          </div>
          <button 
            onClick={handleAudit} 
            disabled={loading || !input.trim()} 
            className="w-full py-5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-900 text-slate-950 rounded-xl font-black font-mono uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 transition-all hover:scale-[1.01] active:scale-95 shadow-lg shadow-cyan-500/10"
          >
            {loading ? <Loader2 className="animate-spin w-4 h-4" /> : <ShieldCheck size={16} />}
            {loading ? "Decrypting Shards..." : "Initialize Intelligence Scan"}
          </button>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl overflow-hidden flex flex-col relative shadow-xl backdrop-blur-md">
          <div className="bg-slate-900/80 px-8 py-3.5 border-b border-slate-800/50 flex justify-between items-center">
            <span className="text-[9px] font-black text-slate-500 font-mono uppercase tracking-widest flex items-center gap-2">
              <Search size={12} className="text-indigo-400" />
              Intelligence Report
            </span>
          </div>
          <div className="flex-1 p-6 overflow-auto font-mono text-xs text-slate-300 scrollbar-hide">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-4">
                 <div className="text-[10px] font-black text-cyan-500 tracking-[0.3em] animate-pulse">Running Neural Analysis...</div>
              </div>
            ) : auditResult ? (
              <div className="space-y-6">
                {showFixPreview && (
                  <div className="animate-in slide-in-from-top-4 duration-300 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl mb-6 relative overflow-hidden">
                    <div className="flex justify-between items-center mb-3">
                      <div className="flex items-center gap-2">
                        <Zap size={14} className="text-emerald-400 fill-current" />
                        <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Remediation Preview</span>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => setShowFixPreview(false)} className="p-1 text-slate-500 hover:text-white transition-colors">
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 text-[10px] max-h-40 overflow-auto mb-4 whitespace-pre text-emerald-100/70">
                      {pendingFix}
                    </div>
                    <button 
                      onClick={applyPendingFix}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-2"
                    >
                      <Check size={14} /> Commit Fix to Buffer
                    </button>
                  </div>
                )}

                <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Executive Summary</p>
                  <p className="text-slate-300 leading-relaxed">{auditResult.summary}</p>
                </div>
                
                <div className="space-y-4">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">Findings Matrix</p>
                  {auditResult.vulnerabilities?.map((v: any, i: number) => {
                    const style = getSeverityStyles(v.severity);
                    return (
                      <div key={i} className={`p-5 rounded-2xl border ${style.bg} ${style.border} space-y-4 transition-all hover:border-white/5`}>
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <div className={`${style.text}`}>{style.icon}</div>
                            <h4 className="font-bold text-white uppercase tracking-tight">{v.title}</h4>
                          </div>
                          <span className={`text-[8px] font-black px-2 py-0.5 rounded border ${style.border} ${style.text}`}>{v.severity}</span>
                        </div>
                        <p className="text-slate-400 leading-relaxed text-[11px]">{v.impact}</p>
                        <div className="space-y-3">
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[10px] overflow-x-auto text-slate-500 whitespace-pre">
                            {v.fixSnippet}
                          </div>
                          <div className="flex justify-end pt-2">
                            <button 
                              onClick={() => initiateFix(i)}
                              className={`flex items-center gap-2 px-4 py-2 bg-slate-900 border ${style.border} ${style.text} text-[9px] font-black rounded-xl hover:bg-slate-800 transition-all uppercase tracking-widest shadow-lg`}
                            >
                              <Zap size={10} fill="currentColor" /> Remediate
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-[0.05]">
                <ShieldCheck size={100} strokeWidth={1} />
                <p className="mt-4 text-[9px] font-black tracking-[0.8em] uppercase">Node Idle</p>
              </div>
            )}
          </div>
          {auditResult && !loading && (
            <div className="p-4 border-t border-slate-800/50 bg-slate-900/40 flex justify-end">
              <button onClick={() => exportToPDF("Security Audit", JSON.stringify(auditResult, null, 2), "CS-AUDIT")} className="text-[9px] text-slate-500 hover:text-cyan-400 font-black uppercase flex items-center gap-2 transition-colors tracking-widest">
                <Download size={12} /> Export Report
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CodeAuditor;