import React, { useState, useRef } from 'react';
import { runCloudGuard } from '../geminiService';
import { exportToPDF, extractTextFromPDF } from '../utils/pdfUtils';
import { Cloud, Loader2, Download, Search, Activity, ShieldAlert, Terminal, Upload, Target, ShieldCheck } from 'lucide-react';
import MatrixRain from './MatrixRain';

const CloudGuard: React.FC<{onAuditComplete: any}> = ({ onAuditComplete }) => {
  const [config, setConfig] = useState('');
  const [auditResult, setAuditResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAudit = async () => {
    if (!config.trim()) return;
    setLoading(true);
    setAuditResult(null);
    try {
      const res = await runCloudGuard(config);
      setAuditResult(res);
      onAuditComplete({ 
        content: config, 
        summary: res.summary || `Infrastructure posture audit complete.`, 
        score: res.score,
        type: 'CLOUD'
      });
    } catch (e) {
      console.error(e);
      alert("System fault during posture audit.");
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      if (file.type === 'application/pdf') {
        const text = await extractTextFromPDF(file);
        setConfig(text);
      } else {
        const reader = new FileReader();
        reader.onload = (event) => {
          setConfig(event.target?.result as string);
        };
        reader.readAsText(file);
      }
    } catch (error) {
      alert("Import failed.");
    } finally {
      setLoading(false);
      if (e.target) e.target.value = '';
    }
  };

  const getSeverityColor = (sev: string) => {
    switch(sev.toUpperCase()) {
      case 'CRITICAL': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'WARNING': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
      default: return 'text-cyan-500 bg-cyan-500/10 border-cyan-500/20';
    }
  };

  return (
    <div className="space-y-8 relative">
      {loading && <MatrixRain />}

      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 z-10 relative">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase font-mono">Cloud Guard</h2>
          <div className="flex items-center gap-2 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
            <p className="text-indigo-500/60 uppercase text-[9px] tracking-[0.3em] font-bold font-mono">Cloud Posture Monitor Active</p>
          </div>
        </div>
        <button 
           onClick={() => fileInputRef.current?.click()}
           className="bg-slate-900/80 px-5 py-3 rounded-xl border border-slate-800 text-[9px] font-black font-mono uppercase tracking-[0.1em] text-slate-400 hover:text-indigo-400 transition-all flex items-center gap-2 backdrop-blur-md"
        >
           <Upload size={14} /> Import Config
           <input ref={fileInputRef} type="file" className="hidden" accept=".txt,.yaml,.yml,.json,.pdf,.tf" onChange={handleFileChange} />
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 z-10 relative">
        <div className="space-y-4">
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
             <div className="flex items-center space-x-3 mb-6">
                <Activity className="w-4 h-4 text-indigo-400" />
                <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.15em] font-mono">Configuration Stream</span>
             </div>
             <textarea 
               value={config} 
               onChange={(e) => setConfig(e.target.value)} 
               placeholder="Paste IAM policies or Terraform logs" 
               className="w-full h-[320px] bg-slate-900/20 border border-slate-800 rounded-xl p-6 text-cyan-50 font-mono text-xs resize-none focus:outline-none focus:border-indigo-500/50 leading-relaxed scrollbar-hide" 
             />
             <button 
               onClick={handleAudit} 
               disabled={loading || !config.trim()} 
               className="mt-6 w-full py-5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-900 text-white rounded-xl font-black font-mono uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 transition-all shadow-lg shadow-indigo-500/10"
             >
                {loading ? <Loader2 className="animate-spin w-4 h-4" /> : <Cloud size={16} />} 
                {loading ? "Calculating Risk..." : "Start Posture Audit"}
             </button>
          </div>
          {auditResult && !loading && (
            <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-8 text-center animate-in zoom-in duration-500 shadow-xl">
              <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3 font-mono">System Posture Index</p>
              <div className="flex items-center justify-center gap-4">
                <p className={`text-6xl font-black ${auditResult.score > 70 ? 'text-emerald-400' : auditResult.score > 40 ? 'text-amber-400' : 'text-rose-500'} font-mono leading-none tracking-tighter`}>{auditResult.score}</p>
                <div className="text-left">
                  <p className="text-lg font-bold text-white/10 font-mono">/ 100</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl overflow-hidden flex flex-col relative backdrop-blur-md shadow-xl">
          <div className="bg-slate-900/80 px-8 py-3.5 border-b border-slate-800/50 flex justify-between items-center">
             <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest font-mono flex items-center gap-3">
               <ShieldAlert size={14} className="text-rose-500" />
               Blast Radius Mapping
             </span>
             {auditResult && (
               <button onClick={() => exportToPDF("Cloud Audit Result", JSON.stringify(auditResult, null, 2), "CS-CSPM")} className="p-2 text-slate-500 hover:text-white transition-all">
                 <Download size={16} />
               </button>
             )}
          </div>
          <div className="flex-1 p-6 overflow-auto font-mono text-xs text-slate-300 scrollbar-hide">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-4">
                <div className="text-[10px] font-black tracking-[0.4em] font-mono text-indigo-400 animate-pulse uppercase">Tracing Vectors...</div>
              </div>
            ) : auditResult ? (
              <div className="space-y-6">
                <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Post-Audit Summary</p>
                  <p className="text-slate-300 leading-relaxed">{auditResult.summary}</p>
                </div>
                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-1">Critical Findings</p>
                   {auditResult.findings.map((f: any, i: number) => (
                     <div key={i} className={`p-5 rounded-2xl border bg-slate-950/40 border-slate-800 space-y-3 transition-all hover:border-indigo-500/20`}>
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-2">
                            <Target size={14} className="text-indigo-400" />
                            <h4 className="font-bold text-white uppercase tracking-tight">{f.title}</h4>
                          </div>
                          <span className={`text-[8px] font-black px-2 py-0.5 rounded border ${getSeverityColor(f.severity)}`}>{f.severity}</span>
                        </div>
                        <div className="space-y-2">
                           <div>
                             <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Blast Radius</p>
                             <p className="text-rose-400/80 text-[10px] font-mono">{f.blastRadius}</p>
                           </div>
                           <div>
                             <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Recommendation</p>
                             <p className="text-slate-400 text-[10px] leading-relaxed">{f.remediation}</p>
                           </div>
                        </div>
                     </div>
                   ))}
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center opacity-[0.05]">
                <Search size={100} strokeWidth={1} />
                <p className="mt-4 text-[9px] font-black tracking-[0.4em] uppercase font-mono">Node Idle</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CloudGuard;