import React, { useState } from 'react';
import { AuditResult } from '../types';
import { exportToPDF, exportAllToPDF } from '../utils/pdfUtils';
import { Download, FileText, Search, Clock, Trash2, Shield, Globe, User, Cloud, Database, FileArchive, X, MoreHorizontal } from 'lucide-react';

interface AuditVaultProps {
  history: AuditResult[];
  onPurge: () => void;
  onDeleteItem: (id: string) => void;
}

const AuditVault: React.FC<AuditVaultProps> = ({ history, onPurge, onDeleteItem }) => {
  const [filter, setFilter] = useState('');

  const filteredHistory = history.filter(item => 
    item.id.toLowerCase().includes(filter.toLowerCase()) || 
    item.type.toLowerCase().includes(filter.toLowerCase())
  );

  const handleDownloadPDF = (audit: AuditResult) => {
    exportToPDF(`${audit.type} Analysis Report`, audit.summary + "\n\n" + audit.content, audit.id);
  };

  const handleExportAll = () => {
    if (history.length === 0) return;
    exportAllToPDF(history);
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'CODE': return <Shield className="w-3.5 h-3.5 text-cyan-400" />;
      case 'CLOUD': return <Cloud className="w-3.5 h-3.5 text-indigo-400" />;
      case 'URL': return <Globe className="w-3.5 h-3.5 text-emerald-400" />;
      case 'OSINT': return <User className="w-3.5 h-3.5 text-orange-400" />;
      default: return <FileText className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <header className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight font-mono uppercase">Audit Vault</h2>
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Encrypted Log Repository</p>
        </div>
        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button 
              onClick={handleExportAll}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-cyan-400 border border-slate-800 text-[9px] font-black rounded-lg uppercase tracking-widest transition-all"
            >
              <FileArchive size={12} /> Full Export
            </button>
          )}
          <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-900/50 border border-slate-800 rounded-lg">
            <Search className="w-3.5 h-3.5 text-slate-500" />
            <input 
              type="text" 
              placeholder="Filter hash..." 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-transparent border-none text-[9px] text-slate-300 focus:outline-none w-20 sm:w-32 font-mono uppercase" 
            />
          </div>
        </div>
      </header>

      <div className="bg-slate-950/40 border border-slate-900 rounded-xl overflow-hidden shadow-2xl backdrop-blur-md">
        <div className="overflow-x-auto scrollbar-hide">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-slate-900/60 text-[8px] font-black text-slate-500 uppercase tracking-[0.3em] border-b border-slate-900">
                <th className="px-4 py-3">Audit ID</th>
                <th className="px-4 py-3">Module</th>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">Summary Trace</th>
                <th className="px-4 py-3 text-right">Ops</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900/50">
              {filteredHistory.length > 0 ? filteredHistory.map((audit) => (
                <tr key={audit.id} className="hover:bg-cyan-500/[0.02] transition-colors group">
                  <td className="px-4 py-3 font-mono text-[9px] text-slate-400 tracking-tighter uppercase whitespace-nowrap">
                    #{audit.id}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      {getIcon(audit.type)}
                      <span className="text-[9px] font-black uppercase text-slate-500">{audit.type}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5 text-[9px] text-slate-600 font-bold whitespace-nowrap">
                      <Clock className="w-2.5 h-2.5" />
                      {audit.timestamp.split(',')[0]}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-400 text-[10px] truncate max-w-[150px] lg:max-w-[300px] leading-tight font-medium">
                    {audit.summary}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleDownloadPDF(audit)}
                        className="p-1.5 text-slate-600 hover:text-cyan-400 bg-slate-900/50 hover:bg-slate-800 rounded transition-all"
                        title="Download PDF"
                      >
                        <Download size={12} />
                      </button>
                      <button 
                        onClick={() => onDeleteItem(audit.id)}
                        className="p-1.5 text-slate-600 hover:text-red-500 bg-slate-900/50 hover:bg-slate-800 rounded transition-all"
                        title="Delete Record"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                    {/* Fallback for touch devices or simple view */}
                    <div className="group-hover:hidden flex justify-end">
                      <MoreHorizontal size={12} className="text-slate-800" />
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-6 py-16 text-center">
                    <div className="flex flex-col items-center justify-center space-y-3 opacity-10">
                      <Database className="w-10 h-10" />
                      <p className="text-[8px] font-black uppercase font-mono tracking-widest">Repository Status: NULL</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {history.length > 0 && (
        <div className="flex justify-center pt-4">
          <button 
            onClick={() => {
              if(confirm("Confirm security vault purge? This action is irreversible.")) {
                onPurge();
              }
            }}
            className="flex items-center gap-2 px-6 py-2 bg-transparent hover:bg-red-500/5 border border-slate-900 hover:border-red-500/20 rounded-lg text-[8px] text-slate-700 hover:text-red-500 font-black uppercase tracking-widest transition-all"
          >
            <Trash2 className="w-3 h-3" />
            <span>Wipe Vault Shards</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default AuditVault;