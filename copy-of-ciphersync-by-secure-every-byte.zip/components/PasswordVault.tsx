import React, { useState, useEffect } from 'react';
import { ShieldCheck, Eye, EyeOff, Key, Zap, Clock, ShieldAlert, Terminal } from 'lucide-react';
import MatrixRain from './MatrixRain';

const PasswordVault: React.FC = () => {
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [stats, setStats] = useState({ entropy: 0, crackTime: 'N/A', complexity: 'Low' });
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    if (!password) { 
      setStats({ entropy: 0, crackTime: 'N/A', complexity: 'None' }); 
      return; 
    }
    
    setAnalyzing(true);
    const timeout = setTimeout(() => {
      let charset = 0;
      if (/[a-z]/.test(password)) charset += 26;
      if (/[A-Z]/.test(password)) charset += 26;
      if (/[0-9]/.test(password)) charset += 10;
      if (/[^a-zA-Z0-9]/.test(password)) charset += 32;
      const entropy = Math.round(password.length * Math.log2(charset));
      const combinations = Math.pow(charset, password.length);
      const secondsToCrack = combinations / 10_000_000_000;
      let timeText = 'Centuries';
      if (secondsToCrack < 1) timeText = 'Instantly';
      else if (secondsToCrack < 3600) timeText = `${Math.round(secondsToCrack / 60)}m`;
      else if (secondsToCrack < 31536000) timeText = `${Math.round(secondsToCrack / 86400)}d`;
      else if (secondsToCrack < 31536000 * 100) timeText = `${Math.round(secondsToCrack / 31536000)}y`;
      setStats({ entropy, crackTime: timeText, complexity: entropy > 90 ? 'Elite' : entropy > 60 ? 'High' : 'Low' });
      setAnalyzing(false);
    }, 400);

    return () => clearTimeout(timeout);
  }, [password]);

  return (
    <div className="space-y-12 max-w-5xl mx-auto relative">
      {analyzing && <MatrixRain />}

      <header className="z-10 relative">
        <h2 className="text-4xl font-black text-white tracking-tighter uppercase font-mono">CRYPT VAULT</h2>
        <div className="flex items-center gap-2 mt-2">
          <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_8px_#06b6d4]"></span>
          <p className="text-cyan-500/60 uppercase text-[10px] tracking-[0.3em] font-black font-mono">Entropy Resistance Audit Secure</p>
        </div>
      </header>

      <div className="bg-slate-950/60 border border-slate-800 rounded-[3.5rem] p-16 space-y-16 shadow-2xl relative overflow-hidden backdrop-blur-md z-10">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 blur-[120px] pointer-events-none"></div>
        
        <div className="relative space-y-8">
          <div className="flex items-center justify-between">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block font-mono">Input Secret Buffer</label>
            <div className="flex items-center gap-2">
               <span className="text-[9px] font-black text-slate-700 font-mono uppercase">AES 256 Enabled</span>
            </div>
          </div>
          <div className="relative group">
            <Key className="absolute left-8 top-1/2 -translate-y-1/2 w-8 h-8 text-slate-700 group-focus-within:text-cyan-400 transition-all duration-300" />
            <input 
              type={showPass ? 'text' : 'password'} 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              className="w-full bg-slate-900/60 border border-slate-800 rounded-[2.5rem] pl-20 pr-20 py-10 text-3xl font-mono text-cyan-50 focus:outline-none focus:border-cyan-500/50 transition-all shadow-inner tracking-widest placeholder:text-slate-800" 
              placeholder="Paste secret token..." 
            />
            <button 
              onClick={() => setShowPass(!showPass)} 
              className="absolute right-8 top-1/2 -translate-y-1/2 text-slate-700 hover:text-cyan-400 transition-colors bg-slate-800 p-3 rounded-2xl border border-white/5"
            >
              {showPass ? <EyeOff size={28} /> : <Eye size={28} />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-10">
          {[
            { label: 'Time To Crack', val: stats.crackTime, icon: Clock, color: 'text-indigo-400' },
            { label: 'Bit Entropy', val: stats.entropy, icon: Zap, color: 'text-amber-400' },
            { label: 'Vault Integrity', val: stats.complexity, icon: ShieldCheck, color: 'text-emerald-400' }
          ].map((s, i) => (
            <div key={i} className="bg-slate-900/40 p-12 rounded-[3rem] border border-slate-800/80 text-center flex flex-col items-center hover:bg-slate-900 transition-all group relative overflow-hidden">
              <div className="absolute inset-0 bg-white/[0.02] opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <s.icon className={`w-10 h-10 ${s.color} mb-6 transition-transform group-hover:scale-125`} />
              <div className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] mb-3 font-mono">{s.label}</div>
              <div className="text-4xl font-black text-white font-mono tracking-tighter uppercase leading-none">{s.val}</div>
            </div>
          ))}
        </div>

        <div className="space-y-8 bg-slate-900/20 p-10 rounded-[3rem] border border-slate-800/50">
          <div className="flex items-center gap-3">
            <Terminal size={18} className="text-slate-500" />
            <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono">Complexity Validation Matrix</h4>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
             {[
               { rule: 'Non-Alphanumeric Chars', met: /[^a-zA-Z0-9]/.test(password) },
               { rule: 'Bimodal Case Mix', met: /[a-z]/.test(password) && /[A-Z]/.test(password) },
               { rule: 'Length Index >= 14', met: password.length >= 14 },
               { rule: 'Integer Infusion', met: /[0-9]/.test(password) },
             ].map((r, i) => (
               <div key={i} className={`flex items-center justify-between px-8 py-6 rounded-2xl border transition-all ${r.met ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400' : 'bg-slate-800/10 border-slate-700/50 text-slate-700'}`}>
                 <span className="text-xs font-black uppercase tracking-widest font-mono">{r.rule}</span>
                 <div className={`w-3 h-3 rounded-full ${r.met ? 'bg-emerald-400 shadow-[0_0_12px_#10b981] animate-pulse' : 'bg-slate-800'}`}></div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PasswordVault;