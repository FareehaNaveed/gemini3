import React, { useState, useRef, useEffect } from 'react';
import { runSOCChat } from '../geminiService';
import { ChatSession, ChatMessage } from '../types';
import { Terminal, Send, Trash2, ShieldAlert, Cpu, Plus, Hash, Clock, ChevronRight, Search, Zap, Edit3, Check, X as CloseIcon } from 'lucide-react';

const SOCChat: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load from storage
  useEffect(() => {
    const saved = localStorage.getItem('ciphersync_soc_sessions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed.length > 0) setActiveSessionId(parsed[0].id);
      } catch (e) {
        console.error("Session reconstruction fault", e);
      }
    } else {
      createNewSession();
    }
  }, []);

  // Save to storage
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('ciphersync_soc_sessions', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [sessions, activeSessionId, loading]);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const createNewSession = () => {
    const newId = `SESS-${Math.floor(Date.now() / 1000)}`;
    const newSession: ChatSession = {
      id: newId,
      title: 'New Intelligence Thread',
      messages: [{ 
        role: 'assistant', 
        text: '[SYSTEM] SOC Master Engine v4.5 active. Establishing encrypted link. State your objective.', 
        timestamp: new Date().toLocaleTimeString() 
      }],
      lastUpdate: new Date().toISOString()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);
  };

  const handleSend = async () => {
    if (!input.trim() || loading || !activeSessionId) return;

    const userText = input.trim();
    setInput('');
    
    const userMsg: ChatMessage = { 
      role: 'user', 
      text: userText, 
      timestamp: new Date().toLocaleTimeString() 
    };

    setSessions(prev => prev.map(s => {
      if (s.id === activeSessionId) {
        // Concisely auto-title based on the first real query
        const isFirstQuery = s.messages.length === 1;
        const autoTitle = isFirstQuery 
          ? userText.split(' ').slice(0, 5).join(' ').substring(0, 25) + (userText.length > 25 ? '...' : '')
          : s.title;

        return { 
          ...s, 
          title: autoTitle,
          messages: [...s.messages, userMsg],
          lastUpdate: new Date().toISOString()
        };
      }
      return s;
    }));

    setLoading(true);

    try {
      const response = await runSOCChat(activeSession?.messages.map(m => ({ role: m.role, text: m.text })) || [], userText);
      
      const assistantMsg: ChatMessage = { 
        role: 'assistant', 
        text: response || "[ERROR] Intelligence stream interrupted.", 
        timestamp: new Date().toLocaleTimeString() 
      };

      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, assistantMsg], lastUpdate: new Date().toISOString() };
        }
        return s;
      }));
    } catch (e) {
      const errorMsg: ChatMessage = { 
        role: 'assistant', 
        text: `[FATAL] ${(e as Error).message}`, 
        timestamp: new Date().toLocaleTimeString() 
      };
      setSessions(prev => prev.map(s => {
        if (s.id === activeSessionId) {
          return { ...s, messages: [...s.messages, errorMsg] };
        }
        return s;
      }));
    } finally {
      setLoading(false);
    }
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Permanently wipe this investigative thread?")) {
      const newSessions = sessions.filter(s => s.id !== id);
      setSessions(newSessions);
      if (activeSessionId === id) {
        setActiveSessionId(newSessions.length > 0 ? newSessions[0].id : null);
      }
    }
  };

  const startRenaming = (id: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(id);
    setEditTitle(currentTitle);
  };

  const saveRename = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (editingSessionId && editTitle.trim()) {
      setSessions(prev => prev.map(s => 
        s.id === editingSessionId ? { ...s, title: editTitle.trim() } : s
      ));
      setEditingSessionId(null);
    }
  };

  const purgeAll = () => {
    if (confirm("PURGE ALL TERMINAL HISTORY? This action is irreversible.")) {
      setSessions([]);
      localStorage.removeItem('ciphersync_soc_sessions');
      createNewSession();
    }
  };

  const filteredSessions = sessions.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-[calc(100vh-12rem)] flex bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl font-mono">
      {/* Sidebar: Session History */}
      <div className="hidden md:flex flex-col w-72 bg-slate-900/50 border-r border-slate-900 overflow-hidden">
        <div className="p-4 border-b border-slate-800 space-y-4">
          <button 
            onClick={createNewSession}
            className="w-full flex items-center justify-center gap-2 py-3 bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-cyan-500/10"
          >
            <Plus size={14} /> New Thread
          </button>
          <div className="flex items-center gap-2 px-3 py-2 bg-slate-950/50 border border-slate-800 rounded-lg">
            <Search size={12} className="text-slate-600" />
            <input 
              type="text" 
              placeholder="Search history..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none text-[9px] text-slate-400 focus:outline-none w-full uppercase"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto scrollbar-hide">
          {filteredSessions.map(session => (
            <div 
              key={session.id}
              onClick={() => setActiveSessionId(session.id)}
              className={`px-4 py-4 cursor-pointer border-b border-slate-800/50 transition-all group relative ${
                activeSessionId === session.id ? 'bg-cyan-500/5 border-r-2 border-r-cyan-400' : 'hover:bg-slate-800/30'
              }`}
            >
              <div className="flex justify-between items-start mb-1">
                {editingSessionId === session.id ? (
                  <form onSubmit={saveRename} className="flex-1 flex items-center gap-1 mr-2" onClick={e => e.stopPropagation()}>
                    <input 
                      autoFocus
                      className="bg-slate-950 border border-cyan-500/50 text-[10px] text-white px-2 py-1 rounded w-full focus:outline-none"
                      value={editTitle}
                      onChange={e => setEditTitle(e.target.value)}
                      onBlur={() => saveRename()}
                    />
                    <button type="submit" className="text-emerald-400"><Check size={12} /></button>
                  </form>
                ) : (
                  <span className={`text-[10px] font-black uppercase truncate pr-12 ${
                    activeSessionId === session.id ? 'text-cyan-400' : 'text-slate-400'
                  }`}>
                    {session.title}
                  </span>
                )}
                
                <div className="absolute top-4 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                  <button 
                    onClick={(e) => startRenaming(session.id, session.title, e)}
                    className="text-slate-600 hover:text-cyan-400 transition-all"
                    title="Rename session"
                  >
                    <Edit3 size={10} />
                  </button>
                  <button 
                    onClick={(e) => deleteSession(session.id, e)}
                    className="text-slate-600 hover:text-red-400 transition-all"
                    title="Delete session"
                  >
                    <Trash2 size={10} />
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-2 text-[8px] text-slate-600 font-bold uppercase tracking-widest">
                <Clock size={8} />
                {new Date(session.lastUpdate).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-800 bg-slate-950/30">
          <button 
            onClick={purgeAll}
            className="w-full text-[9px] font-black text-slate-600 hover:text-red-500 uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-colors"
          >
            <Zap size={10} /> Purge Terminal
          </button>
        </div>
      </div>

      {/* Main Terminal View */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="bg-slate-900/80 backdrop-blur-md px-6 py-4 border-b border-slate-800 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="bg-cyan-500/10 p-2 rounded border border-cyan-500/20">
              <Cpu className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-black text-white uppercase tracking-widest truncate">
                {activeSession?.title || 'Terminal Offline'}
              </h3>
              <p className="text-[10px] text-slate-500 flex items-center">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
                Node {activeSessionId || 'NULL'} :: Direct Path Stable
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-[9px] text-slate-600 font-black uppercase tracking-widest border border-slate-800 px-3 py-1 rounded-full">
              AES-256 E2EE
            </div>
          </div>
        </div>

        <div ref={scrollRef} className="flex-1 p-4 sm:p-8 overflow-auto font-mono text-sm relative">
          <div className="absolute inset-0 scan-line opacity-5 pointer-events-none"></div>
          <div className="space-y-8">
            {activeSession?.messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
                <div className={`max-w-[95%] sm:max-w-[85%] rounded-2xl p-5 ${
                  msg.role === 'user' 
                    ? 'bg-slate-800/80 text-slate-200 border border-slate-700 shadow-xl' 
                    : 'bg-slate-900/40 text-cyan-50 border border-cyan-900/20 shadow-lg'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <div className="text-[9px] font-black uppercase opacity-40 flex items-center gap-2 tracking-[0.15em]">
                      {msg.role === 'user' ? (
                        <>User Node @ CIPHERSYNC <Hash size={8} /></>
                      ) : (
                        <>SEC Intelligence Unit <ShieldAlert size={10} className="text-cyan-400" /></>
                      )}
                    </div>
                    <span className="text-[8px] font-bold text-slate-600">{msg.timestamp}</span>
                  </div>
                  <div className="whitespace-pre-wrap leading-relaxed text-[13px]">
                    {msg.text}
                  </div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-900/40 text-cyan-500/50 border border-cyan-900/20 rounded-2xl px-6 py-5 animate-pulse italic text-xs flex items-center gap-3">
                  <Terminal size={12} className="animate-bounce" />
                  Neural Reasoning in Progress...
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="p-6 bg-slate-900/30 border-t border-slate-800 backdrop-blur-md">
          <div className="flex items-center space-x-3 bg-slate-950 border border-slate-800 rounded-2xl px-5 py-2 focus-within:border-cyan-500/50 transition-all shadow-inner">
            <span className="text-cyan-500 font-bold text-lg">$</span>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Query intelligence core..."
              className="flex-1 bg-transparent border-none focus:outline-none text-slate-100 font-mono text-sm py-4"
              disabled={loading}
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || loading || !activeSessionId}
              className="p-3 bg-cyan-600/10 hover:bg-cyan-600 text-cyan-400 hover:text-slate-950 rounded-xl disabled:opacity-30 transition-all group"
            >
              <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </button>
          </div>
          <div className="mt-3 flex justify-center">
             <p className="text-[8px] text-slate-700 font-black uppercase tracking-[0.4em]">Proprietary Defensive Intelligence Protocol Active</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SOCChat;