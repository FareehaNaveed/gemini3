import React, { useState } from 'react';
import { runUrlAnalysis, runOsintSearch } from '../geminiService';
import { Search, Loader2, Globe, User, ShieldAlert, LayoutGrid, Terminal, ExternalLink } from 'lucide-react';
import MatrixRain from './MatrixRain';

const OSINTScan: React.FC<{onAuditComplete: any}> = ({ onAuditComplete }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'URL' | 'USER'>('URL');

  const handleScan = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const res = mode === 'URL' ? await runUrlAnalysis(input) : await runOsintSearch(input);
      setResult(res);
      onAuditComplete({ content: input, summary: `${mode} Intrusion Recon` });
    } catch (e) {
      setResult('SCAN FAILURE: CS INT X - ' + (e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 relative">
      {loading && <MatrixRain />}

      <header className="z-10 relative">
        <h2 className="text-4xl font-black text-white tracking-tighter uppercase font-mono">INTEL RECON</h2>
        <div className="flex items-center gap-2 mt-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <p className="text-emerald-500/60 uppercase text-[10px] tracking-[0.3em] font-black font-mono">Deep OSINT Surveillance Active</p>
        </div>
      </header>

      <div className="flex bg-slate-900/80 p-2.5 rounded-[2.5rem] border border-slate-800 w-fit backdrop-blur-md z-10 relative shadow-xl">
        <button 
          onClick={() => {setMode('URL'); setInput(''); setResult('');}} 
          className={`flex items-center gap-2 px-10 py-4 rounded-[1.8rem] text-[10px] font-black font-mono tracking-widest uppercase transition-all ${mode === 'URL' ? 'bg-cyan-600 text-slate-950 shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
        >
          <Globe size={14} /> URL SCANNER
        </button>
        <button 
          onClick={() => {setMode('USER'); setInput(''); setResult('');}} 
          className={`flex items-center gap-2 px-10 py-4 rounded-[1.8rem] text-[10px] font-black font-mono tracking-widest uppercase transition-all ${mode === 'USER' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
        >
          <User size={14} /> USER RECON
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 z-10 relative">
        <div className="bg-slate-950/60 border border-slate-800 rounded-[3.5rem] p-12 space-y-10 shadow-xl backdrop-blur-md">
          <div className="space-y-8">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-slate-900 rounded-2xl border border-white/5">
                {mode === 'URL' ? <Globe className="w-7 h-7 text-cyan-400" /> : <User className="w-7 h-7 text-indigo-400" />}
              </div>
              <div>
                <h3 className="text-2xl font-black text-white font-mono uppercase leading-none">
                  {mode === 'URL' ? 'Link Infiltration' : 'Digital Footprint'}
                </h3>
                <p className="text-[10px] text-slate-500 font-mono mt-1 font-bold uppercase tracking-widest">Metadata Extraction Engine</p>
              </div>
            </div>
            
            <div className="relative group">
              <Terminal className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-slate-700 group-focus-within:text-cyan-500 transition-colors" />
              <input 
                type="text" 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                onKeyDown={(e) => e.key === 'Enter' && handleScan()}
                placeholder={mode === 'URL' ? "Enter target URL..." : "Enter identifier..." } 
                className="w-full bg-slate-900/80 border border-slate-800 rounded-[2rem] px-16 py-7 text-cyan-50 font-mono text-lg focus:outline-none focus:border-cyan-500/50 transition-all shadow-inner" 
              />
            </div>

            <button 
              onClick={handleScan} 
              disabled={loading || !input.trim()} 
              className="w-full py-7 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-900 text-slate-950 rounded-[2rem] font-black font-mono uppercase tracking-[0.4em] text-xs flex items-center justify-center gap-5 transition-all hover:scale-[1.02] shadow-[0_15px_40px_rgba(16,185,129,0.2)] group"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Search className="group-hover:scale-125 transition-transform" />} 
              {loading ? "SEARCHING DARK NODES..." : "INITIATE DEEP RECON"}
            </button>
          </div>
        </div>

        <div className="bg-slate-950/80 border border-slate-800 rounded-[3.5rem] p-12 min-h-[450px] relative shadow-2xl backdrop-blur-xl flex flex-col">
          <div className="flex justify-between items-center mb-10">
            <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest font-mono flex items-center gap-4 opacity-60">
              <ShieldAlert size={16} className="text-cyan-400" /> Intelligence Stream Report
            </div>
            {result && (
              <a href="#" className="text-[10px] font-black text-cyan-500 hover:text-cyan-400 flex items-center gap-2 font-mono tracking-widest uppercase">
                <ExternalLink size={14} /> View Graph
              </a>
            )}
          </div>
          <div className="flex-1 font-mono text-sm leading-relaxed text-slate-300 whitespace-pre-wrap overflow-auto scrollbar-hide">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-6">
                <div className="w-16 h-1 border-slate-800 bg-slate-900 overflow-hidden rounded-full">
                  <div className="h-full bg-cyan-500 animate-progress"></div>
                </div>
                <div className="text-[10px] font-black tracking-[0.6em] font-mono animate-pulse uppercase">QUERYING GLOBAL NETS</div>
              </div>
            ) : result || (
              <div className="h-full flex flex-col items-center justify-center opacity-5 grayscale">
                <LayoutGrid size={140} strokeWidth={1} />
                <p className="mt-8 text-[11px] font-black tracking-[0.8em] uppercase font-mono">Awaiting Target Data</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes progress {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-progress {
          animation: progress 1.5s ease-in-out infinite;
          width: 50%;
        }
      `}</style>
    </div>
  );
};

export default OSINTScan;