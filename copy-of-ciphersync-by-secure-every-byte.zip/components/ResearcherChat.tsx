import React, { useState, useRef, useEffect } from 'react';
import { runSOCChat as runSecurityResearcherChat } from '../geminiService';
import { Terminal, Send, Trash2, ShieldAlert } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

const ResearcherChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'CipherSync Researcher Online. Engine 3 active. How can I assist with your defensive posture today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const response = await runSecurityResearcherChat(messages.map(m => ({ role: m.role, text: m.text })), userMsg);
      setMessages(prev => [...prev, { role: 'assistant', text: response || "I couldn't process that query." }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'assistant', text: `SYSTEM ERROR: ${(e as Error).message}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl">
      <div className="bg-slate-900 px-6 py-4 border-b border-slate-800 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="bg-cyan-500/10 p-2 rounded border border-cyan-500/20">
            <Terminal className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-widest">SOC Researcher Terminal</h3>
            <p className="text-[10px] text-slate-500 flex items-center">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1.5 animate-pulse"></span>
              CipherSync Intelligence Core Stable
            </p>
          </div>
        </div>
        <button 
          onClick={() => setMessages([{ role: 'assistant', text: 'Session cleared. Ready for new input.' }])}
          className="text-slate-600 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 p-6 overflow-auto font-mono text-sm scroll-smooth">
        <div className="space-y-6">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-lg p-4 ${
                msg.role === 'user' 
                  ? 'bg-slate-800 text-slate-200 border border-slate-700' 
                  : 'bg-slate-900/50 text-cyan-50 border border-cyan-900/30'
              }`}>
                <div className="text-[10px] font-bold uppercase mb-2 opacity-50 flex items-center">
                  {msg.role === 'user' ? (
                    'Guest User @ CIPHERSYNC >'
                  ) : (
                    <>
                      <ShieldAlert className="w-3 h-3 mr-1 text-cyan-400" />
                      Researcher Node
                    </>
                  )}
                </div>
                <div className="whitespace-pre-wrap leading-relaxed">
                  {msg.text}
                </div>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-900/50 text-cyan-500/50 border border-cyan-900/30 rounded-lg p-4 animate-pulse italic">
                Reasoning in progress...
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-4 bg-slate-900/50 border-t border-slate-800">
        <div className="flex items-center space-x-2 bg-slate-950 border border-slate-800 rounded-xl p-2 px-4 focus-within:border-cyan-500/50 transition-all">
          <span className="text-cyan-500 font-bold">$</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask a technical security question..."
            className="flex-1 bg-transparent border-none focus:outline-none text-slate-100 font-mono text-sm py-2"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className="p-2 text-slate-500 hover:text-cyan-400 disabled:opacity-30 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResearcherChat;