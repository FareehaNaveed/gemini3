import React from 'react';
import { AppTab } from '../types';
import { 
  ShieldCheck, 
  Cloud, 
  MessageSquare, 
  LayoutDashboard, 
  Database,
  Search,
  Key,
  Lock,
  X
} from 'lucide-react';

interface SidebarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  closeSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, closeSidebar }) => {
  const menuItems = [
    { id: AppTab.DASHBOARD, label: 'Control Center', icon: LayoutDashboard },
    { id: AppTab.CODE_AUDITOR, label: 'Code Auditor', icon: ShieldCheck },
    { id: AppTab.CLOUD_GUARD, label: 'Cloud Guard', icon: Cloud },
    { id: AppTab.OSINT_SCAN, label: 'OSINT Scan', icon: Search },
    { id: AppTab.PASSWORD_VAULT, label: 'Pass Vault', icon: Key },
    { id: AppTab.SOC_CHAT, label: 'SOC Terminal', icon: MessageSquare },
    { id: AppTab.AUDIT_VAULT, label: 'Audit Vault', icon: Database },
  ];

  return (
    <div className="w-full h-full flex flex-col bg-[#020617] border-r border-slate-900/50">
      <div className="p-8 pb-10 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="bg-cyan-500/10 p-2.5 rounded-xl border border-cyan-500/30">
            <Lock className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white font-mono leading-none">CIPHERSYNC</h1>
            <p className="text-[10px] uppercase tracking-[0.3em] text-cyan-500/50 font-black">SECURE SYSTEM</p>
          </div>
        </div>
        <button onClick={closeSidebar} className="lg:hidden text-slate-500 hover:text-white"><X size={24} /></button>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-4 px-6 py-4 rounded-2xl transition-all duration-300 group hover:translate-x-2 ${
                isActive 
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_20px_rgba(6,182,212,0.1)]' 
                  : 'text-slate-500 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 transition-colors ${isActive ? 'text-cyan-400' : 'text-slate-600 group-hover:text-cyan-400'}`} />
              <span className="text-[11px] font-bold uppercase tracking-widest font-mono">{item.label}</span>
              {isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]"></div>}
            </button>
          );
        })}
      </nav>

      <div className="p-8 mt-auto">
        <div className="bg-slate-900/40 rounded-3xl p-6 border border-slate-800">
          <div className="flex items-center space-x-2 mb-3">
            <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
            <span className="text-[10px] text-cyan-500 uppercase font-bold tracking-widest font-mono">STATUS ACTIVE</span>
          </div>
          <p className="text-[10px] text-slate-500 font-mono leading-relaxed opacity-70">
            All nodes operational. AES encrypted connection.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;