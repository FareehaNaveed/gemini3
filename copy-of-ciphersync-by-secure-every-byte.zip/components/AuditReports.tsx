
import React from 'react';
import { AuditResult } from '../types';
import { Download, FileText, Search, Clock, Trash2, ExternalLink } from 'lucide-react';

interface AuditReportsProps {
  history: AuditResult[];
}

const AuditReports: React.FC<AuditReportsProps> = ({ history }) => {
  const downloadPDF = (audit: AuditResult) => {
    // In a real app, you'd use jsPDF here. For this demo, we simulate the trigger.
    alert(`Generating PDF Report for ${audit.id}...\n\nCipherSync Defensive Audit\nTimestamp: ${audit.timestamp}\nType: ${audit.type}\n\n[Full audit contents would be rendered in PDF format]`);
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">Audit Reports</h2>
          <p className="text-slate-400 mt-1">Immutable session history and exported security documentation.</p>
        </div>
        <div className="flex items-center space-x-2 px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl">
          <Search className="w-4 h-4 text-slate-500" />
          <input type="text" placeholder="Search hash..." className="bg-transparent border-none text-xs text-slate-300 focus:outline-none w-32" />
        </div>
      </header>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              <th className="px-6 py-4">Audit ID</th>
              <th className="px-6 py-4">Engine Type</th>
              <th className="px-6 py-4">Timestamp</th>
              <th className="px-6 py-4">Summary</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {history.length > 0 ? history.map((audit) => (
              <tr key={audit.id} className="hover:bg-slate-800/30 transition-colors group">
                <td className="px-6 py-4 font-mono text-xs text-cyan-400">0x{audit.id.toUpperCase()}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    audit.type === 'CODE' ? 'bg-cyan-500/10 text-cyan-400' : 'bg-indigo-500/10 text-indigo-400'
                  }`}>
                    {audit.type} Engine
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-500 text-xs flex items-center space-x-2">
                  <Clock className="w-3 h-3" />
                  <span>{audit.timestamp}</span>
                </td>
                <td className="px-6 py-4 text-slate-300 text-xs truncate max-w-xs">{audit.summary}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => downloadPDF(audit)}
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-all"
                      title="Download PDF"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button 
                      className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded transition-all"
                      title="View Details"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-20 text-center">
                   <div className="flex flex-col items-center justify-center space-y-3 opacity-20">
                      <FileText className="w-16 h-16" />
                      <p className="text-sm font-medium">No audit logs found in vault.</p>
                   </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {history.length > 0 && (
        <div className="flex justify-center">
          <button className="text-[10px] text-slate-500 hover:text-slate-300 flex items-center space-x-1 uppercase tracking-widest font-bold">
            <Trash2 className="w-3 h-3" />
            <span>Wipe Local Data Vault</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default AuditReports;
