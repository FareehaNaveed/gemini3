import React, { useState, useEffect } from 'react';
import { ShieldAlert, Database, CheckCircle2, Map as MapIcon, Zap, Radio, Terminal, Server, Globe2, X, ListFilter } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const dailyData = [
  { day: 'MON', vulns: 45, high: 12 },
  { day: 'TUE', vulns: 52, high: 15 },
  { day: 'WED', vulns: 38, high: 8 },
  { day: 'THU', vulns: 65, high: 22 },
  { day: 'FRI', vulns: 48, high: 10 },
  { day: 'SAT', vulns: 72, high: 28 },
  { day: 'SUN', vulns: 55, high: 18 },
];

const firewallRules = [
  { id: 'RL-101', priority: 10, service: 'HTTPS', action: 'ALLOW', target: 'ANY', status: 'ACTIVE' },
  { id: 'RL-102', priority: 20, service: 'SSH', action: 'DENY', target: 'EXTERNAL', status: 'ACTIVE' },
  { id: 'RL-103', priority: 30, service: 'DB_PORT', action: 'ALLOW', target: 'INTERNAL_ONLY', status: 'ACTIVE' },
  { id: 'RL-104', priority: 40, service: 'SMTP', action: 'RATE_LIMIT', target: 'ANY', status: 'MONITORING' },
  { id: 'RL-105', priority: 50, service: 'ICMP', action: 'DENY', target: 'ANY', status: 'ACTIVE' },
];

const Dashboard: React.FC<{ auditCount: number }> = ({ auditCount }) => {
  const [attacks, setAttacks] = useState<{x: number, y: number, id: number, label: string}[]>([]);
  const [logs, setLogs] = useState<{id: string, action: string, src: string, type: string}[]>([]);
  const [showRules, setShowRules] = useState(false);

  useEffect(() => {
    const targets = ["NEW_YORK", "LONDON", "TOKYO", "MOSCOW", "SAO_PAULO"];
    const interval = setInterval(() => {
      setAttacks(prev => [...prev.slice(-6), { x: 15 + Math.random() * 70, y: 25 + Math.random() * 50, id: Date.now(), label: targets[Math.floor(Math.random() * targets.length)] }]);
      setLogs(prev => [{ id: `FL-${Math.floor(100+Math.random()*900)}`, action: 'BLOCKED', src: `${Math.floor(Math.random()*255)}.12.5.9`, type: 'SQL PROBE' }, ...prev.slice(0, 5)]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-12 pb-20 relative">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-5xl font-black text-white tracking-tighter font-mono uppercase">Control Center</h2>
          <div className="flex items-center space-x-3 mt-2">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span className="text-cyan-500/60 uppercase text-[10px] tracking-[0.4em] font-bold font-mono">Live Node Stream Active</span>
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 px-8 rounded-3xl border border-slate-800 flex items-center space-x-4">
           <div className="text-right">
             <p className="text-[10px] text-slate-500 font-bold uppercase font-mono tracking-widest">Global Status</p>
             <p className="text-sm text-white font-mono font-bold tracking-tight uppercase">Operational State</p>
           </div>
           <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.1)]">
             <Globe2 className="w-5 h-5 text-cyan-400" />
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Threat State', val: 'STABLE', sub: 'MITIGATION ACTIVE', icon: ShieldAlert, color: 'text-emerald-400' },
          { label: 'Secured Data', val: '1.2 PB', sub: 'OPTIMIZED', icon: Database, color: 'text-cyan-400' },
          { label: 'Vault Entry', val: auditCount.toString(), sub: 'TOTAL RECORDS', icon: Zap, color: 'text-amber-400' },
          { label: 'Neural Health', val: '99.9%', sub: 'ZERO FAULT', icon: CheckCircle2, color: 'text-indigo-400' },
        ].map((stat, i) => (
          <div key={i} className="bg-slate-900/40 border border-slate-800/80 p-8 rounded-[2rem] relative overflow-hidden group hover:translate-y-[-4px] transition-all duration-300">
            <div className={`p-3.5 rounded-2xl bg-slate-800/50 mb-6 border border-white/5 w-fit`}>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <div className="text-3xl font-black text-white font-mono tracking-tighter mb-1 uppercase leading-none">{stat.val}</div>
            <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest font-mono opacity-60">{stat.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/30 border border-slate-800/80 rounded-[3rem] p-10 relative overflow-hidden backdrop-blur-xl">
           <div className="flex justify-between items-center mb-8">
             <h3 className="text-xl font-black text-white flex items-center gap-4 font-mono uppercase tracking-tight">
               <MapIcon size={24} className="text-cyan-400" /> Global Threat Feed
             </h3>
             <span className="text-[10px] font-bold text-red-500 font-mono animate-pulse uppercase tracking-[0.2em]">Intercepting...</span>
           </div>
           <div className="aspect-[21/9] w-full bg-slate-950/80 rounded-[2.5rem] relative overflow-hidden border border-slate-800/50">
              <div className="absolute inset-0 scan-line opacity-10 pointer-events-none"></div>
              {attacks.map(attack => (
                <div key={attack.id} className="attack-node" style={{ left: `${attack.x}%`, top: `${attack.y}%` }}>
                  <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-slate-900/95 backdrop-blur-md px-4 py-2 rounded-xl border border-red-500/20 text-[10px] font-mono font-bold text-red-400 whitespace-nowrap shadow-2xl scale-in">
                    MITIGATED // {attack.label}
                  </div>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-slate-900/30 border border-slate-800/80 rounded-[3rem] p-10 backdrop-blur-xl flex flex-col">
           <div className="flex justify-between items-center mb-8">
             <h3 className="text-xl font-black text-white font-mono flex items-center gap-3 uppercase tracking-tight">
               <Terminal size={20} className="text-cyan-400" /> System Logs
             </h3>
           </div>
           <div className="space-y-4 flex-1">
             {logs.map((log, i) => (
               <div key={log.id} className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/50 flex justify-between items-center hover:bg-slate-950 transition-colors">
                 <div className="space-y-1">
                   <p className="text-[10px] font-mono text-slate-500 font-bold tracking-tight uppercase">SRC {log.src}</p>
                   <p className="text-xs font-bold text-slate-200 font-mono uppercase tracking-tight">{log.type}</p>
                 </div>
                 <div className="px-2.5 py-1 rounded-lg text-[9px] font-black font-mono tracking-widest bg-red-500/10 text-red-500 uppercase border border-red-500/20">{log.action}</div>
               </div>
             ))}
           </div>
           <button 
             onClick={() => setShowRules(true)}
             className="mt-8 w-full py-5 bg-slate-800 hover:bg-cyan-600/10 hover:text-cyan-400 text-slate-400 text-[11px] font-bold rounded-2xl transition-all border border-slate-700/60 uppercase tracking-widest font-mono flex items-center justify-center gap-3"
           >
             <Server size={14} className="text-cyan-400" /> Manage Rules
           </button>
        </div>
      </div>

      {/* Firewall Rules Modal */}
      {showRules && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 sm:p-12">
           <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-lg" onClick={() => setShowRules(false)}></div>
           <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-[3rem] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-300">
              <div className="bg-slate-800/50 p-8 border-b border-slate-700/50 flex justify-between items-center">
                 <div className="flex items-center gap-4">
                    <div className="p-2 bg-cyan-500/10 rounded-xl border border-cyan-500/30">
                       <ListFilter className="text-cyan-400" size={24} />
                    </div>
                    <div>
                       <h3 className="text-2xl font-black text-white font-mono uppercase tracking-tight">Access Control Matrix</h3>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Immutable Policy Vault</p>
                    </div>
                 </div>
                 <button onClick={() => setShowRules(false)} className="text-slate-500 hover:text-white transition-colors">
                    <X size={28} />
                 </button>
              </div>
              
              <div className="p-10 overflow-auto max-h-[60vh] scrollbar-hide">
                 <table className="w-full text-left">
                    <thead>
                       <tr className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] border-b border-slate-800">
                          <th className="pb-6">ID</th>
                          <th className="pb-6">Priority</th>
                          <th className="pb-6">Service</th>
                          <th className="pb-6">Action</th>
                          <th className="pb-6">Target</th>
                          <th className="pb-6 text-right">Status</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                       {firewallRules.map((rule) => (
                          <tr key={rule.id} className="text-sm font-mono text-slate-300 hover:bg-slate-800/30 transition-colors group">
                             <td className="py-6 text-cyan-400 font-bold">{rule.id}</td>
                             <td className="py-6">{rule.priority}</td>
                             <td className="py-6 font-bold">{rule.service}</td>
                             <td className="py-6">
                                <span className={`px-3 py-1 rounded-lg text-[10px] font-black ${
                                   rule.action === 'DENY' ? 'bg-red-500/10 text-red-500' : 
                                   rule.action === 'ALLOW' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                                }`}>
                                   {rule.action}
                                </span>
                             </td>
                             <td className="py-6">{rule.target}</td>
                             <td className="py-6 text-right">
                                <span className="flex items-center justify-end gap-2 text-[10px] font-bold text-slate-500 tracking-widest uppercase">
                                   <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
                                   {rule.status}
                                </span>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
              
              <div className="bg-slate-800/30 p-8 border-t border-slate-700/50 flex justify-end gap-4">
                 <button onClick={() => setShowRules(false)} className="px-10 py-4 bg-slate-800 text-slate-400 text-[11px] font-bold rounded-2xl uppercase tracking-widest hover:text-white transition-all">Close</button>
                 <button className="px-10 py-4 bg-cyan-600 text-slate-950 text-[11px] font-black rounded-2xl uppercase tracking-widest hover:bg-cyan-500 transition-all shadow-lg shadow-cyan-500/20">Commit Changes</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;